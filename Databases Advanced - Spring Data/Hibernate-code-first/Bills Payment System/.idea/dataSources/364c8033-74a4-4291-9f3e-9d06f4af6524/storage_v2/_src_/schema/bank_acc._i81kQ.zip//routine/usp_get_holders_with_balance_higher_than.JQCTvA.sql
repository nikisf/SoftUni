create
    definer = root@localhost procedure usp_get_holders_with_balance_higher_than(IN balance_highter decimal)
begin
select `first_name`, `last_name` from account_holders as ah
join accounts as a
on a.account_holder_id = ah.id
group by a.account_holder_id
having sum(a.balance) > balance_highter
order by a.id;
end;

