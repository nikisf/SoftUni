create
    definer = root@localhost procedure usp_calculate_future_value_for_account(IN account_id int, IN interest_rate decimal(10, 4))
begin
select a.`id`, ah.`first_name`, ah.`last_name`, a.`balance` as account_balance,ufn_calculate_future_value(a.`balance`, interest_rate, 5) AS balance_in_5_years
 from account_holders as ah
join accounts as a
on a.account_holder_id = ah.id
where account_id = a.id;
end;

