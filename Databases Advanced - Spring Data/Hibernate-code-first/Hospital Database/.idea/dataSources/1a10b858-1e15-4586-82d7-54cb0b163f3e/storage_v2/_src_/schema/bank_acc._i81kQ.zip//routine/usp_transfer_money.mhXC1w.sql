create
    definer = root@localhost procedure usp_transfer_money(IN from_account_id int, IN to_account_id int, IN amount decimal(20, 4))
begin
start transaction;
if (select `id` from accounts where id = from_account_id) IS NULL then ROLLBACK;
elseif (select `id` from accounts where id = to_account_id) IS NULL then ROLLBACK;
elseif amount < 0 then ROLLBACK;
elseif amount > (select `balance` from accounts where from_account_id = id) then ROLLBACK;
elseif from_account_id = to_account_id then ROLLBACK;
else 
update accounts
set balance = balance - amount 
    where from_account_id = id;
update accounts
set balance = balance + amount 
    where to_account_id = id;
    END IF;
end;

