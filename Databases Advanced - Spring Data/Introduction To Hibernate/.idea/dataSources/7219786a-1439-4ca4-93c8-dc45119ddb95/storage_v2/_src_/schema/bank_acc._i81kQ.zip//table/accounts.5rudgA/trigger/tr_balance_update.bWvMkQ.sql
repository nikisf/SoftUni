create definer = root@localhost trigger tr_balance_update
    after update
    on accounts
    for each row
BEGIN 
 IF OLD.balance <> NEW.balance then
 INSERT INTO `logs`(account_id, old_sum, new_sum) VALUES (old.id, old.balance, new.balance);
 END IF;
 end;

